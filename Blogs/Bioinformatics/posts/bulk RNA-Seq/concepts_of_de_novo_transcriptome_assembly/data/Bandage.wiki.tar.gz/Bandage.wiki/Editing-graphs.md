This page describes the various ways that a user can alter a graph using Bandage.  They can all be accessed via the 'Edit' menu in Bandage's main menu bar.  Note that most of these features first appeared in v0.7.0, so if you do not see them, please download a more recent version.

None of these actions will alter an assembly graph file – i.e. unwanted edits can always be undone by reloading the graph from file.  If you wish to save your edited graph, Bandage can output to GFA files (see [[Output]]).

Also note that many of these actions will change the graph sufficiently to invalidate a [[BLAST search|BLAST searches]] you may have conducted in Bandage.  You may therefore find your BLAST results disappear after a graph edit and BLAST searches must be redone.

### Hide selected nodes

This action will remove the selected nodes from the visualisation, but not from the actual graph.  Any edges connected to the hidden nodes will also be hidden.  However, you cannot hide only edges – i.e. if both of an edge's nodes are shown in the graph, the edge will always be shown.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/hide_nodes.png" alt="Hide selected nodes">
</p>

Since hiding nodes does not remove them from the graph, by clicking 'Draw graph' again you will redo the graph layout and the hidden nodes will be show once more.

This action can be completed using Backspace (Delete on Mac).

### Remove selection from graph

This action will remove the selected nodes and edges from the graph.  Edges can be removed separately from their nodes, disconnecting components in the graph.  However, when a node is removed, all of its edges are also removed.  Also note that nodes and edges are always removed in their complementary pairs – e.g. it is not possible to remove a positive node while leaving its negative counterpart in the graph.

Unlike using 'Hide selected nodes', the removed components of the graph are permanently gone and cannot be seen by redrawing the graph.  The change in the graph will be reflected in the graph information section of the main Bandage window.  To restore removed components, you must reload the graph file.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/remove_selection.png" alt="Remove selection from graph">
</p>

This action can be completed using Shift+Backspace (Shift+Delete on Mac).

### Duplicate selected nodes

This action will duplicate each of the selected nodes in the graph.  Of the two resulting nodes, one will keep the original node name and the other will have '_copy' appended to the end of its name.  All of the nodes edges will also be duplicated.  Nodes are always duplicated with their complement nodes, so if you are viewing the graph in double style (see [[Single vs double node style]]), you will see both the positive and negative nodes be duplicated.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/duplicate_node.png" alt="Duplicate selected nodes">
</p>

The node's read depth is split between the two resulting nodes.  E.g. if the original node had a read depth of 50.0, the two resulting nodes will each have a depth of 25.0.

This action can be completed using Ctrl+D (⌘+D on Mac).

### Merge selected nodes

This action will merge selected nodes, if possible.  Nodes can be merged if they form a simple, unbranching path.  Any branching will prevent a merge from occurring.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/merge_selected.png" alt="Merge selected nodes">
</p>

Such unbranching paths are not likely to occur in some assembly graphs (as the assembler would have already combined them) but can be created by deleting nodes from the graph.

This action can be completed using Ctrl+M (⌘+M on Mac).

### Merge all possible nodes

This action will look through the entire graph and merge any nodes that can be merged.  It is particularly useful for Trinity.fasta graphs, where long linear strings of nodes are common.  Performing 'Merge all possible nodes' on such a graph can greatly simplify it.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/merge_all.png" alt="Merge all possible nodes">
</p>

This action can be completed using Shift+Ctrl+M (Shift+⌘+M on Mac).

### Change node name

If only one node is selected, you may use this action to rename the node.  Node names cannot contain spaces, tabs, newlines or commas, and you cannot use a name that is already used by a node in the graph.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/change_node_name.png" alt="Change node name">
</p>

### Change node read depth

If one or more nodes are selected, you may use this action to adjust their read depth.

<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/change_node_read_depth.png" alt="Change node read depth">
</p>
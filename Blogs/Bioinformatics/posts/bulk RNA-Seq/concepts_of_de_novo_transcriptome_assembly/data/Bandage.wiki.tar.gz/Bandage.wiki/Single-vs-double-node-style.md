### Node pairs

Due to the complementary nature of DNA, assembly graph nodes actually come in pairs where their sequences are reverse complements of each other.  Bandage names nodes ending with either '+' or '-', so for example, node 5+ is the reverse complement of 5- and vice-versa.  Note that depending on the assembler, a node being 'positive' or 'negative' may have no real meaning – it can be random which node in a pair is positive vs negative.  See [[assembler differences|Assembler differences]] for more information.

### Double node style
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/double_nodes.png" alt="Double mode">
</p>
By selecting 'Double' in the 'Graph drawing' section of the main Bandage window, you can view the graph in double node style.  In this mode, the two nodes in a pair are drawn separately – the full graph structure is illustrated.  Since nodes in an assembly graph have directionality, these nodes are drawn with arrowheads on their 3' ends.

Double node style can be useful in understanding complex areas.  However, for simpler graphs, double style may be an unnecessary complication.

### Single node style
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/single_nodes.png" alt="Single mode">
</p>

By selecting 'Single' in the 'Graph drawing' section of the main Bandage window (the default setting), you can view the graph in single node style.  In this mode, one node is drawn to the screen to represent both nodes in a complementary pair.  Since the visualised nodes represent both directions, they do not have arrowheads and are named without a '+' or '-'.

Graphs drawn in single style are visually simpler.  They have half the number of displayed nodes and edges, which results in a less cluttered appearance and improved performance.  However, complex areas of the graph can be more difficult to understand in single style.

### Node names

There are two places in Bandage where you can specify nodes either with or without the +/- at the end: when using the 'Around nodes' graph scope and when searching using 'Find nodes'.  In these cases, when a node name is given without the +/-, it is assumed that you are referring to both nodes in the pair.  For example, if you search for the node named '5', Bandage will find both node '5+' and '5-'.  If you include the +/-, then you refer to only one node in the pair.

When specifying an exact path in Bandage, it is necessary to use the +/- in node names.  For this reason, double mode can be useful when specifying exact paths.  See [[graph paths|Graph paths]] for more information.

### BLAST hits

When BLAST hits are displayed on a double mode graph, the hits are only drawn on the node that represents their forward match:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/double_mode_blast.png" alt="Single mode">
</p>
When BLAST hits are displayed on a single mode graph, all hits are drawn together on the same node:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/single_mode_blast.png" alt="Single mode">
</p>
For more information, see [[BLAST searches|BLAST searches]].

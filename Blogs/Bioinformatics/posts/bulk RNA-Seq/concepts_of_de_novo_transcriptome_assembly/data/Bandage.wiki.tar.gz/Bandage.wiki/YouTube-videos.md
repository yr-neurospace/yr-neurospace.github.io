The following links are to YouTube videos which showcase Bandage features:

<a href="http://www.youtube.com/watch?v=cierloa5hS0" target="_blank">Bandage introduction</a>

<a href="http://www.youtube.com/watch?v=rzdQq663lQw" target="_blank">Bandage controls</a>

<a href="http://www.youtube.com/watch?v=VuRN28XyFcI" target="_blank">Bandage graph shape</a>
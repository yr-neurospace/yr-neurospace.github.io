Bandage has multiple different node colouring schemes that can be selected via a drop-down menu in the main window:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/colour_scheme_combo_box.png" alt="Colour scheme menu">
</p>

### Random colours

This colour scheme gives each node a random hue.  The colours are different each time it is selected, so changing the scheme away from and back to 'Random colours' will result in different node colours.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/random_colours.png" alt="Random colours">
</p>
There are a number of settings to control the saturation, lightness and opacity of nodes in this colour scheme in the 'Random colour scheme' section of Bandage settings.  These can be adjusted independently for positive and negative nodes, potentially useful when a graph is drawn in double mode.

### Uniform colour

This colour scheme gives nodes uniform colours.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/uniform_colours.png" alt="Uniform colour">
</p>
The 'Uniform colour scheme' section of Bandage settings allows you to specify the colours used in this scheme.  Different colours can be used for positive, negative and 'special' nodes. 'Special' nodes are the user-specified nodes used in the 'Around nodes' scope and nodes with BLAST hits in the 'Around BLAST hits' scope.

### Colour by depth

This colour scheme gives nodes different colours based on their depth.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/colour_by_read_depth.png" alt="Colour by read depth">
</p>
Nodes with a low depth are one colour (default: black), nodes with a high depth are another colour (default: red) and nodes with intermediate depths are intermediate colours.  By default, the 'low' and 'high' cutoffs are the first and third quartiles, respectively.  These cutoffs, as well as the colours used, are configurable in the 'Depth colour scheme' section of Bandage settings.

### BLAST hits (solid)

This colour scheme gives all nodes the same colour and highlights BLAST hits on the nodes using a colour specific to the BLAST query.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/blast_solid_colours.png" alt="BLAST hits (solid)">
</p>
This scheme is useful when multiple BLAST queries are displayed on the graph simultaneously.  The colour of the nodes is configurable in the 'BLAST colour scheme' section of Bandage settings.  The colour for each hit is configurable by clicking the colour button in the BLAST queries table in the BLAST search window.

### BLAST hits (rainbow)

This colour scheme gives all nodes the same colour and highlights BLAST hits on the nodes using colours related to the position in the BLAST query.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/blast_rainbow_colours.png" alt="BLAST hits (rainbow)">
</p>
This scheme is useful when a single BLAST query is displayed on the graph.  The colour of the nodes is configurable in the 'BLAST colour scheme' section of Bandage settings.

### Colour by contiguity

This colour scheme allows you to highlight nodes in the graph which are likely to be contiguous with one or more starting nodes.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/colour_by_contiguity.png" alt="Colour by contiguity">
</p>
To use this scheme, select one or more nodes and then click the 'Determine contiguity' button.  Nodes will then be coloured based on their contiguity.  The colours are configurable in the 'Contiguity colour scheme' section of Bandage settings.  The defaults are:
* Bright green = starting node
* Dark green = contiguous node
* Light green = possibly contiguous node
* Grey = not contiguous node

For more information, see [[determining contiguity|Determining contiguity]].



### Custom colours

This colour scheme allows the user to apply any colour to selected nodes.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/custom_colours.png" alt="Custom colours">
</p>
When nodes are selected, a 'Set colour' button is available on the right side of the main Bandage window (in the selection panel).  Clicking this button produces a colour picker where you can choose a node colour. If the graph is saved to a GFA file, user-applied custom colours will be saved in the file and automatically applied when the graph is reloaded in Bandage (see [[output|Output]]).

Custom colours can also be loaded via CSV file (see [[CSV labels]]).

### Other colours

The colours for graph edges, node outlines, text and text outlines can also be configured.  These settings are in the 'Graph appearance' and 'Text appearance' sections of the Bandage settings.
Bandage can load CSV files contain additional data to display on the graph.  Thanks to Elmar Pruesse for this feature!

### CSV format

The CSV file must have the following format:
* Two or more columns, where the first column contains node names and the other columns contain data to display.
* A header row containing labels for each column.

The node name column can accept node names in a few different formats.  They can be the full node headers that Bandage uses when saving nodes to file (e.g. NODE_1+_length_6070_cov_43.3434) or simply the node name itself (e.g. 1+).  If the node's directionality is not given (with a '+' or '-'), the positive node will be assumed.  The header for the node name column can be anything (or empty) as it is not used.

### Example CSV files
Here are two valid examples of node label CSV files which could be loaded by Bandage:

```
Node name,First base,Last base
NODE_1+_length_6070_cov_43.3434,T,C
NODE_2+_length_9792_cov_41.771,T,T
NODE_3+_length_5869_cov_43.038,T,C
NODE_4+_length_123_cov_119.957,T,G
```

```
Name,Double length,Half length
1,12140,3035
2,19584,4896
3,11738,2934.5
4,246,61.5
```

### Loading CSV label data

To load a CSV file containing node labels, use the 'Load CSV label data' menu item in Bandage's 'File' menu.

### Display on graph

To view the loaded labels, tick the 'CSV data' box in the 'Node labels' section of the main Bandage window.  You can then use the drop down menu to choose which column of the CSV file to display.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/csv_labels.png" alt="CSV labels on graph">
</p>

### Colours

CSV files can also include colours, which will set the nodes' custom colours (see [[Colour schemes]]). This is done by using 'Colour' (or 'Color') as one of the CSV headers. You can use any of the [X11 colour names](https://en.wikipedia.org/wiki/X11_color_names) or specify colours as hex codes. For example:

```
Name,Colour
A,red
B,blue
C,medium aquamarine
D,#fa8072
```

### About me
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/ryan_wick.jpg" alt="Ryan Wick">
</p>
My name is Ryan Wick, and I made Bandage while doing a Master's in Bioinformatics at the University of Melbourne.  I am originally from the US, where I did my undergraduate degree in Biology at the University of Wisconsin–Madison.

I now continue to develop Bandage as a research assistant in [Kathryn Holt](http://www.biochemistry.unimelb.edu.au/research/res_holt.html)'s [research group](http://holtlab.net/) at the Bio21 institute in the University of Melbourne.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/uni_melb_and_sys_gen.png" alt="University of Melbourne and Centre for Systems Genomics logos">
</p>

### Contact

Email: rrwick@gmail.com

Twitter: [@rrwick](https://twitter.com/rrwick)

### Citation

If you use Bandage in your research, please cite the following publication: [Wick R.R., Schultz M.B., Zobel J. & Holt K.E. (2015). Bandage: interactive visualization of _de novo_ genome assemblies. _Bioinformatics_, 31(20), 3350-3352.](http://bioinformatics.oxfordjournals.org/content/31/20/3350)

### Acknowledgements

Research supervisors:
* [Kathryn Holt](http://www.biochemistry.unimelb.edu.au/research/res_holt.html)
* [Justin Zobel](http://people.eng.unimelb.edu.au/jzobel/)
* [Mark Schultz](http://www.genetics.unimelb.edu.au/person/academics/mschultz.html)

Early users/testers:
* Simon Gladman
* Jane Hawkey
* Zoe Dyson
* Yu Wan
* Torsten Seemann
* David Edwards

Contributors:
* Rayan Chikhi
* Elmar Pruesse

### Awards

Bandage won the [2015 National iAward](http://www.iawards.com.au/index.php/winners/2015-winners/2015-national-winners) in the postgraduate student category.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/iawards.png" alt="iAward logo">
</p>
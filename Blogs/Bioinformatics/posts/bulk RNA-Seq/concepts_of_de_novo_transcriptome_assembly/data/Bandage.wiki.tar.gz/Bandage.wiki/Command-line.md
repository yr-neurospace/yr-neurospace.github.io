Bandage can be run from the command line with this usage: `Bandage <command> [options]`

Type `Bandage --help` to see general help (which lists possible commands) and `Bandage <command> --help` to see help for that particular command. The `--helpall` option will show all possible Bandage settings that can be specified on the command line.

### Operating systems

##### Linux

Command line usage on Linux is straightforward. Either run Bandage from a particular directory (e.g. `./Bandage` or `~/programs/Bandage`) or copy it to a directory in your path to run it simply using `Bandage`.

##### Mac

Bandage for Mac is packaged as an application bundle which is actually a directory. To run Bandage via the command line, you must call the executable that is contained in the bundle: `Bandage.app/Contents/MacOS/Bandage`

##### Windows

Command line support is not fully functional on Windows. The program can be called with commands and options, and it should run correctly. But since Windows views it as a GUI application, not a command line application, there will be no output to the console.

### No command

Usage: `Bandage [options]`

If Bandage is loaded from the command line without any particular command, it will simply launch the Bandage GUI.  You can use command line options to adjust Bandage's settings.

##### Examples:
* Load Bandage with default settings:
  * `Bandage`
* Load Bandage and set edges to be wider and dark red:
  * `Bandage --edgewidth 6.0 --edgecol darkred`
* Load Bandage and turn on node name and node length labels:
  * `Bandage --names --lengths`


### Bandage load

Usage: `Bandage load <graph> [options]`

When the load command is used, Bandage will load a graph immediately after opening.  The `--draw` option will make Bandage draw the graph after loading it.

##### Examples:
* Load a graph but do not draw it:
  * `Bandage load graph.fastg`
* Load a graph and draw the entire graph:
  * `Bandage load graph.fastg --draw`
* Load a graph, conduct a BLAST search and draw the entire graph:
  * `Bandage load graph.fastg --draw --query genes.fasta`
* Load a graph, conduct a BLAST search and draw the region(s) of the graph surrounding BLAST hits:
  * `Bandage load graph.fastg --draw --query genes.fasta --scope aroundblast --distance 3`


### Bandage info

Bandage info takes a graph file as input and outputs the following statistics
about the graph:
* Node count: The number of nodes in the graph. Only positive nodes are counted (i.e. each complementary pair counts as one).
* Edge count: The number of edges in the graph. Only one edge in each complementary pair is counted.
* Total length: The total number of base pairs in the graph.
* Dead ends: The number of instances where an end of a node does not connect to any other nodes.
* Percentage dead ends: The proportion of possible dead ends. The maximum number of dead ends is twice the number of nodes (occurs when there are no edges), so this value is the number of dead ends divided by twice the node count.
* Connected components: The number of regions of the graph which are disconnected from each other.
* Largest component: The total number of base pairs in the largest connected component.
* N50: Nodes that are this length or greater will collectively add up to at least half of the total length.
* Shortest node: The length of the shortest node in the graph.
* Lower quartile node: The median node length for the shorter half of the nodes.
* Median node: The median node length for the graph.
* Upper quartile node: The median node length for the longer half of the nodes.
* Longest node: The length of the longest node in the graph.

Usage: `Bandage info <graph>`

##### Example output:
```
Node count:               561
Edge count:               734
Total length (bp):        4878380
Dead ends:                33
Percentage dead ends:     2.94118%
Connected components:     19
Largest component (bp):   4821329
N50 (bp):            90360
Shortest node (bp):       1
Lower quartile node (bp): 17
Median node (bp):         87
Upper quartile node (bp): 404
Longest node (bp):        205425
```

### Bandage image

Bandage image will generate an image file of the graph visualisation without opening the GUI.

Usage: `Bandage image <graph> <outputfile> [options]`

##### Examples:
* Create a jpg image of the graph:
  * `Bandage image graph.fastg image.jpg`
* Create an svg image of the graph with uniform node colours:
  * `Bandage image graph.fastg image.svg --colour uniform`
* Create a png image of the region(s) of the graph surrounding BLAST hits:
  * `Bandage image graph.fastg image.png --query genes.fasta --scope aroundblast --distance 3`


### Bandage querypaths

Bandage querypaths searches for queries in the graph using BLAST and outputs the results to a tab-delimited file.

Usage: `Bandage querypaths <graph> <queries> <output_prefix> [options]`

### Bandage reduce

Bandage reduce takes an input graph and saves a reduced subgraph using the graph scope settings. The saved graph will be in GFA format.

If a graph scope is not specified, then the 'entire' scope will be used, in which case this will simply convert the input graph to GFA format.

Usage: `Bandage reduce <inputgraph> <outputgraph> [options]`

##### Examples:
* Create a reduced graph containing only high read depth nodes:
  * `Bandage reduce graph.fastg high_depth_graph.gfa --scope depthrange --mindepth 100.0 --maxdepth 1000000`
* Create a reduced graph containing only nodes around a gene of interest:
  * `Bandage reduce graph.fastg high_depth_graph.gfa --scope aroundblast --distance 5 --query gene.fasta`
* Convert a FASTG graph to GFA:
  * `Bandage reduce graph.fastg graph.gfa`
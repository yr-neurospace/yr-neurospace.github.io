For a simple case, imagine a bacterial genome that contains a single repeated element in two separate places in the chromosome:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/simple_example_1.png" alt="Simple example 1">
</p>

A researcher (who does not yet know the structure of the genome) sequences it, and the resulting 100 bp reads are assembled with a _de novo_ assembler:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/simple_example_2.png" alt="Simple example 2">
</p>

Because the repeated element is longer than the sequencing reads, the assembler was not able to reproduce the original genome as a single contig. Rather, three contigs are produced: one for the repeated sequence (even though it occurs twice) and one for each sequence between the repeated elements.

Given only the contigs, the relationship between these sequences is not clear. However, the assembly graph contains additional information which is made apparent in Bandage:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/simple_example_3.png" alt="Simple example 3">
</p>

There are two principal underlying sequences compatible with this graph: two separate circular sequences that share a region in common, or a single larger circular sequence with an element that occurs twice:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/simple_example_4.png" alt="Simple example 4">
</p>

Additional knowledge, such as information on the approximate size of the bacterial chromosome, can help the researcher to rule out the first alternative. In this way, Bandage has assisted in turning a fragmented assembly of three contigs into a completed genome of one sequence.
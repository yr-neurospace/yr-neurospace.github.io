### Installation

Go to either the [Bandage website](http://rrwick.github.io/Bandage/) or the [GitHub releases page](https://github.com/rrwick/Bandage/releases) to download pre-built 64 bit executables for Mac, Windows or Linux.  The Mac and Windows versions should come with all necessary libraries included and should work on OS X 10.7 or later and Windows 7 or later.

The Linux version is available in two flavours: dynamically-linked, which does not contain the GUI code, and statically-linked, which does.  The dynamically-linked version is preferable, as it will use native GUI components, but it may be necessary to install the Qt5 package.  The statically-linked version of Bandage has fewer dependencies but uses non-native GUI components.

It is also possible to build Bandage from source – the instructions are in the [Bandage readme](https://github.com/rrwick/Bandage/blob/master/README.md).

### Starting up the application

Note that, as somewhat unusual on Linux, the Bandage binary starts with a capital "B". So, to start it from the terminal, do the following, taking note of the capital "B":

```bash
Bandage &
```

### In-application help

Many items in Bandage have a help icon next to them: <img src="http://rrwick.github.io/Bandage/images/helptext.png" alt="help text icon" width="16" height="16">.  Click these to read a description of that part of Bandage.

### Supported formats

Bandage currently supports loading assembly graphs in the LastGraph format (used by [Velvet](https://www.ebi.ac.uk/~zerbino/velvet/)), the FASTG format (used by [SPAdes](http://bioinf.spbau.ru/spades) and [MEGAHIT](https://github.com/voutcn/megahit)), the Trinity.fasta format (used by [Trinity](http://trinityrnaseq.github.io/)), the ASQG format (used by [SGA](https://github.com/jts/sga) and [StriDe](https://github.com/ythuang0522/StriDe)), and the [GFA format](https://github.com/pmelsted/GFA-spec/blob/master/GFA-spec.md) (used by [ABySS](https://github.com/bcgsc/abyss) and other programs). If you are using IDBA, check out [this tool](https://github.com/rrwick/IDBA-to-GFA) for converting an IDBA graph into GFA format. See [[assembler differences|Assembler differences]] for more information.

### Load a graph

Before you can do anything else in Bandage, you must load an assembly graph.  Do this by choosing 'Load graph' from the 'File' menu.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/load_graph.png" alt="Load graph">
</p>
If you need a graph to examine, a small sample graph is included in the zip files containing pre-built Bandage binaries.  You can also download a couple of other graphs here:

* [An _E. coli_ genome assembly from Velvet](http://rrwick.github.io/Bandage/samples/E_coli_LastGraph.zip)
* [A small mouse transcriptome from Trinity](http://rrwick.github.io/Bandage/samples/Trinity.fasta.zip)

Small graphs should load quickly, though it may take some time for very large assembly graphs to load (see [[working with very large graphs|Working with very large graphs]]).

### Draw the graph

After the graph is loaded, you can click the 'Draw graph' button to draw the graph to the screen.  This step performs the graph layout, and the time it takes depends on the size of the graph and the graph layout settings (see [[graph layout and appearance|Graph layout and appearance]]).
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/draw_graph.png" alt="Draw graph">
</p>
For smaller graphs, such as a bacterial genome, drawing the entire graph is usually feasible.  However, for a larger graph, such as a metagenome or eukaryote assembly, it is advisable to reduce the graph scope before drawing the graph (see [[graph scope|Graph scope]]).

### Controls

Note that on a Mac, the Command key (⌘) is used instead of the Ctrl key in the below instructions.

##### Selection

* Click on any node or edge to select it.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/select_nodes_1.gif" alt="Selecting nodes">
</p>

* Holding Ctrl while clicking on nodes or edges adds them to or removes them from the selection.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/select_nodes_2.gif" alt="Selecting nodes">
</p>

* Click and drag to select large numbers of nodes and edges.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/select_nodes_3.gif" alt="Selecting nodes">
</p>

##### Moving nodes

* Left click and drag on any node to move it. For short nodes, this will move the entire node. For long nodes, this will move the region of the node near the mouse cursor.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/move_nodes_1.gif" alt="Moving nodes">
</p>

* Right click and drag on any node to move it one piece at a time. This is useful for fine-tuning the shape of a graph or for rotating short nodes.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/move_nodes_2.gif" alt="Moving nodes">
</p>

* Selected nodes are moved in their entirety when dragged. If multiple nodes are selected, they can all be moved together.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/move_nodes_3.gif" alt="Moving nodes">
</p>

##### Mouse navigation

* Ctrl+mouse wheel to zoom the view in to and out from the location of your mouse cursor.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/zoom.gif" alt="Zoom">
</p>

* Ctrl+click and drag with the left mouse button to pan the view.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/pan.gif" alt="Pan">
</p>

* Ctrl+click and drag with the right mouse button to rotate the view.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/rotate.gif" alt="Rotate">
</p>

##### Touchpad navigation

If your OS and touchpad support these gestures (Macs and OS X do), they can be used in Bandage:
* Two-finger scroll to pan the view.
* Two-finger pinch to zoom in and out.
* Two-finger rotate to rotate the view.

##### Keyboard navigation controls

* It is first necessary to click in the viewport (or use tab until it is selected) so it will receive keyboard input.
* Use Ctrl+Plus and Ctrl+Minus to zoom in and out.
* Use arrow keys to pan the viewport horizontally and vertically.
* Use Ctrl+Shift+Plus and Ctrl+Shift+Minus to rotate the view clockwise and anti-clockwise.
Bandage uses [BLAST](http://blast.ncbi.nlm.nih.gov/Blast.cgi) to search for sequences in the assembly graph, and it can then display the hits on the graph visualisation.  It can use both blastn (for nucleotide queries) and tblastn (for protein queries).

### BLAST installation

Before you can use BLAST in Bandage, it must be installed on the same computer.  NCBI has BLAST installation instructions in the [BLAST Command Line Applications User Manual](http://www.ncbi.nlm.nih.gov/books/NBK279671/).  Alternatively, BLAST can be installed using a package manager, e.g.:
* `brew install blast` (using Homebrew on Mac)
* `sudo apt-get install ncbi-blast+` (using APT on Ubuntu)

### BLAST search in Bandage

After a graph is loaded, you may click the 'Create/view BLAST search' button to open the BLAST search window.

##### Building a BLAST database

The first step to conducting a BLAST search is building a BLAST database using all of the graph nodes.  Do this by clicking the 'Build BLAST database' button.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/build_blast_database.png" alt="Build BLAST database">
</p>
The amount of time this takes depends on the size of the graph.  The BLAST database files are stored in your operating system's temporary directory and will be deleted when Bandage is closed.

##### Loading queries

BLAST queries can be loaded from a FASTA file (which may contain multiple sequences) or typed/pasted in manually.  Both nucleotide and protein queries can be used.  Each query is given a colour which can be changed by clicking the colour's button.  A query's name can be changed by editing the 'Query name' cell in the table.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/blast_queries.png" alt="BLAST queries">
</p>
Some information regarding the queries (hits, percent found and paths) are not available until after the BLAST search has been completed.

##### Running a BLAST search

Before a BLAST search is run, you may type in additional command line parameters to be used by blastn and/or tblastn.  Refer to the [BLAST documentation](http://www.ncbi.nlm.nih.gov/books/NBK279675/) for a full list of available options.  Bandage can also filter the BLAST hits by a number of values.  Click the 'Set BLAST hit filters' button to configure these filters.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/run_blast_search_gui.png" alt="Run BLAST search">
</p>
Click the 'Run BLAST search' button to actually conduct the search.  The amount of time this takes depends on the size of the graph and the number of BLAST queries.

### Viewing and interpreting BLAST results

##### Raw output

After the BLAST search completes, the results will appear in the table at the bottom of the BLAST search window.  These are the results as outputted by the BLAST command line tools, and they can be sorted by clicking in the column headers.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/raw_blast_results.png" alt="Raw BLAST results">
</p>

##### On graph

In the main Bandage window, there is a drop-down menu where you can select which query (or all queries) to display on the graph.  These can be highlighted in colour using two of Bandage's [[colour schemes|Colour schemes]]:
* BLAST hits (solid): displays each BLAST hit using the colour of the corresponding query.  This mode is useful when displaying multiple queries on the graph at once.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/solid_blast.png" alt="BLAST hits (solid)">
</p>

* BLAST hits (rainbow): displays each BLAST hit coloured by its position in its query.  This mode is useful when looking at a single query at a time.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/rainbow_blast.png" alt="BLAST hits (rainbow)">
</p>

In the main Bandage window, you can tick the 'BLAST hits' box in the 'Node labels' section to label each BLAST hit with the name of its query.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/blast_labels.png" alt="BLAST labels">
</p>
In the BLAST search window, there is a column in the queries table titled 'Show' which contains a tick box.  If you untick this box for a query, its hits will be hidden on the graph.  This allows you to only view a subset of the BLAST queries at a given time.

##### Query paths

Bandage attempts to find possible paths through the graph which represent a query (see [[graph paths|Graph paths]]).  This is particularly useful when a single query (such as a gene) is split over multiple nodes.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/blast_query_path.png" alt="BLAST query path">
</p>
The number of BLAST query paths is visible in the 'Paths' column of the queries table in the BLAST search window.  If at least one path for a query is found, click in this table cell to open a new window showing details of each possible path.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/blast_query_paths_table.png" alt="BLAST query paths table">
</p>
The criteria Bandage uses to determine query paths are configurable in the 'BLAST query paths' section of Bandage's settings.


### Web BLAST node sequences

It is also possible to use the NCBI BLAST web page to identify node sequences.  With one or more nodes selected, choose the 'Web BLAST selected nodes' item in the 'Output' menu.

If the selected nodes have a total length of about 8 kilobases or less, Bandage will load the NCBI BLAST webpage with your sequences already present in the query section.  You can then adjust the search options and click 'BLAST' to perform the search.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/web_blast.png" alt="Web BLAST">
</p>
However, if your selected sequences are longer than about 8 kilobases, then they are too long to pass to the BLAST web site via the URL.  In this case, Bandage will put the sequences in your computer's clipboard and load the NCBI BLAST webpage.  You must then paste your sequence into the query box before beginning the BLAST search.
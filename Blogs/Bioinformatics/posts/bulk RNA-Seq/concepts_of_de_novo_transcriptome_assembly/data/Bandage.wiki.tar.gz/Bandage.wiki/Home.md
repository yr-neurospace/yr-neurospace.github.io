# <img src="http://rrwick.github.io/Bandage/images/logo.png" alt="Bandage" width="115" height="115" align="middle">Bandage

Bandage (a **B**ioinformatics **A**pplication for **N**avigating _**D**e novo_ **A**ssembly **G**raphs **E**asily), is a program that creates interactive visualisations of assembly graphs.  Sequence assembler programs (such as [Velvet](https://www.ebi.ac.uk/~zerbino/velvet/), [SPAdes](http://bioinf.spbau.ru/spades), [Trinity](http://trinityrnaseq.github.io/) and [MEGAHIT](https://github.com/voutcn/megahit)) carry out assembly by building a graph, from which contigs are generated.  By granting easy access to these assembly graphs, Bandage allows users to better understand, troubleshoot and improve their assemblies.

With Bandage, you can zoom and pan around the graph, customise the visualisation, search for sequences, extract sequences, and more.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/bandage_gui.png" alt="Bandage GUI">
</p>

## Next: [[Getting started|Getting started]]
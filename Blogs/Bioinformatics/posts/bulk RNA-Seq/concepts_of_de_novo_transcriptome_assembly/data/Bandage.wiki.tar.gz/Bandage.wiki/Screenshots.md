This page contains some miscellaneous screenshots of Bandage.

### Varying k-mer size

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot01.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot01_thumb.png" alt="K-mer 21 graph">
    </a>
<figcaption>
    <br>K-mer of 21. This value is too small, resulting in short contigs and many connections, giving a dense tangled graph.
</figcaption>
</figure>
</p>

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot02.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot02_thumb.png" alt="K-mer 77 graph">
    </a>
<figcaption>
    <br>K-mer of 77. This is a good balance, giving long contigs that are well connected.
</figcaption>
</figure>
</p>

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot03.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot03_thumb.png" alt="K-mer 127 graph">
    </a>
<figcaption>
    <br>K-mer of 127. This value is too large, resulting in the graph breaking into many discontinuous pieces.
</figcaption>
</figure>
</p>

### Single vs double nodes

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot04.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot04_thumb.png" alt="Single nodes">
    </a>
<figcaption>
    <br>Single nodes, each holding both forward and reverse sequences.
</figcaption>
</figure>
</p>

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot05.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot05_thumb.png" alt="Double nodes">
    </a>
<figcaption>
    <br>Double nodes, where forward and reverse nodes are drawn separately.
</figcaption>
</figure>
</p>

### Custom colours and labels

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot06.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot06_thumb.png" alt="Custom colours and labels">
    </a>
<figcaption>
    <br>A bacterial transposon that shares a gene with the cloning vector.
</figcaption>
</figure>
</p>

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot07.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot07_thumb.png" alt="Custom colours and labels">
    </a>
<figcaption>
    <br>Assembly graph from metagenomic reads that align to particular 16S genes.
</figcaption>
</figure>
</p>

### Large metagenome graph

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot08.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot08_thumb.png" alt="Metagenome, zoomed out">
    </a>
<figcaption>
    <br>Zoomed out view, showing large-scale structure.
</figcaption>
</figure>
</p>

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot09.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot09_thumb.png" alt="Metagenome, zoomed in">
    </a>
<figcaption>
    <br>Zoomed in view of smaller subgraphs.
</figcaption>
</figure>
</p>

### BLAST search for transposon

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot10.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot10_thumb.png" alt="BLAST for transposon">
    </a>
<figcaption>
    <br>The entire assembly graph.
</figcaption>
</figure>
</p>

<p align="center">
<figure>
    <a href="http://rrwick.github.io/Bandage/images/screenshots/screenshot11.png" target="_blank">
       <img src="http://rrwick.github.io/Bandage/images/screenshots/screenshot11_thumb.png" alt="BLAST for transposon">
    </a>
<figcaption>
    <br>Reduced scope to only nodes containing BLAST hits.
</figcaption>
</figure>
</p>
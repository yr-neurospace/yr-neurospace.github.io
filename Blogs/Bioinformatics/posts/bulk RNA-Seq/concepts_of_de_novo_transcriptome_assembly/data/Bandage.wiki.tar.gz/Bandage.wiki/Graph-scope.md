Before drawing a graph, you can adjust which nodes be drawn using the 'Scope' drop down menu in the 'Graph drawing' section of the main Bandage window.  Graph edges are drawn only when both of the nodes they connect are drawn as well.

### Entire graph

Choosing the 'Entire graph' scope will result in the entire graph being drawn to the screen.  If the style is 'Single', this will be every positive node, and if the style is 'Double', this will every positive and every negative node (see [[single vs double node style|Single vs double node style]]).
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/entire_graph.png" alt="Entire graph">
</p>
The 'Entire graph' scope is appropriate for smaller assembly graphs (up to about 1000 nodes).  However, for very large assembly graphs, the 'Entire graph' scope may result in long layout times and slow graphical performance.  For more information, see [[working with very large graphs|Working with very large graphs]].

### Around nodes
If you happen to know the node name(s) for areas of the graph in which you are interested, you can used the 'Around nodes' scope.  For this scope, you specify one or more node names (separated by commas) in the 'Node(s)' text box, and Bandage will only draw the graph around those nodes.  The 'Distance' option allow you to specify how far to extend the graph (measured in nodes).
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/around_nodes.gif" alt="Around nodes">
</p>
By changing 'Match' from 'Exact' to 'Partial', Bandage will draw the graph around any nodes whose names contain your input.  This can be useful for cases where nodes have prefixes, as is the case for Trinity graphs (see [[assembler differences|Assembler differences]]).
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/partial_node_match.png" alt="Partial node name match">
</p>

### Around BLAST hits

The 'Around BLAST hits' scope works similarly to the 'Around nodes' scope, except that instead of using user-specified node names, it draws the graph around BLAST hits.  It is therefore necessary to first conduct a BLAST search before using this scope (see [[BLAST searches|BLAST searches]]).
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/around_blast.gif" alt="Around BLAST hits">
</p>

### Depth range

The 'Depth range' scope allows you to only visualise nodes which are within a defined range of depths.  This can be useful for excluding node with very low or very high depths.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/read_depth_scope.gif" alt="Read depth range">
</p>

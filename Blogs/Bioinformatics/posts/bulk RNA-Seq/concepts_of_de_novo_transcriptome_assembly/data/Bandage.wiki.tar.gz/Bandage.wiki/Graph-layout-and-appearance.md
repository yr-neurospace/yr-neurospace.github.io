### Graph layout
The 'Graph layout' section of Bandage settings controls how the nodes are physically arranged for display.  Note that you must redraw the graph (by clicking 'Draw graph' in the main Bandage window) to see the effect of changing these settings.

Each displayed node is made up of one or more line segments.  The 'Base pairs per segment' setting controls how many line segments are used for each node.  High values make nodes shorter, and a very high value will result in all nodes being approximately the same size (one line segment).  Low values make nodes longer and result in a tighter relationship between the length of a node's sequence and the node's displayed length.

By default, Bandage will automatically determine an appropriate 'Base pairs per segment' value, but you can switch the setting to 'Manual' to specify a custom value.  Use caution with very low values, which will result in very long nodes and impact Bandage performance.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/bp_per_segment.gif" alt="Base pairs per segment">
</p>
The 'Graph layout iterations' setting controls how long Bandage spends positioning the nodes.  A low value makes graph layout faster, but can result in messier layouts.  A high value makes graph layout slower, but often gives cleaner layouts.  Lower settings are recommended for large graphs.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/layout_quality.gif" alt="Graph layout iterations">
</p>

### Graph appearance
The 'Graph appearance' section of Bandage settings controls graph edges, node outlines and antialiasing.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/graph_appearance.gif" alt="Graph appearance iterations">
</p>
Antialiasing improves the quality of the image, but at a performance cost.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/aa.gif" alt="Antialiasing">
</p>

### Read depth and node width
The 'Read depth and node width' section of Bandage settings controls the relationship between a node's read depth and its width.  Nodes with an average read depth will have the width specified by the 'Node width' setting in the main Bandage window.  Nodes with lower read depth will be narrower and nodes with higher read depth will be wider.

To prevent nodes with very high read depth from appearing excessively wide, the relationship uses a function with a power between 0.1 and 1.0.
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/node_width.gif" alt="Node width">
</p>

### Text appearance
Control over node label text is available in the 'Text appearance' section of Bandage settings:
<p align="center">
  <img src="http://rrwick.github.io/Bandage/images/wiki/text.gif" alt="Text appearance">
</p>